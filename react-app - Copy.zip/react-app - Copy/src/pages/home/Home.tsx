import React, { useState, useEffect } from 'react';
import LogoutButton from '../../components/auth/Logout';
import Profile from '../../components/user/profile';

interface Child {
  text: string;
}

interface Section {
  children: Child[];
}

interface PageData {
  title: string;
  createdAt: string;  updatedAt: string;
  content: Section[];
}

const apiUrl = 'http://localhost:3000/api/pages/65ba35b8afe4a3067fed4472?locale=undefined&draft=false&depth=1';

function Home() {
  const [pageData, setPageData] = useState<PageData | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(apiUrl);
        console.log(response);
        if (response.ok) {
          const data = await response.json();
          setPageData(data);
        } else {
          console.error('Error fetching data:', response.statusText);
        }
      } catch (error) {
        console.error('Error:', error);
      }
    };

    fetchData();
  }, []); 

  return (
    <div className="App">
      {pageData ? (
        <>
          <h1>{pageData.title}</h1>
          <p>Created At: {pageData.createdAt}</p>
          <p>Updated At: {pageData.updatedAt}</p>
          <div>
            {pageData.content.map((section, index) => (
              <div key={index}>
                {section.children.map((child, idx) => (
                  <p key={idx}>{child.text}</p>
                ))}
              </div>
            ))}
          </div>
          <Profile />
          <LogoutButton />
        </>
      ) : (
        <p>Loading...</p>
      )}
    </div>
  );
}

export default Home;
