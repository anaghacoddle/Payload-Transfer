import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css';
import './pages/home/Home'
import Home from './pages/home/Home';
import LoginButton from './components/auth/Login';
function App() {

return (
<Router>
      <Routes>
        {/* <Route path="/" element={<LoginButton />} /> */}
        {/* <Route path="/login" element={<LoginButton />} /> */}
        <Route path="/" element={<Home />} />
        </Routes>
        </Router>
  );
}

export default App;
