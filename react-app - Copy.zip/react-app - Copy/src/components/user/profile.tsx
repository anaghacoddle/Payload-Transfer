import { useAuth0 } from "@auth0/auth0-react";
import React, { useCallback, useEffect } from "react";

const Profile = () => {
  const { user, isAuthenticated, isLoading } = useAuth0();

  const fetchData = useCallback(async () => {
    try {
      await fetch('http://localhost:3000/api/login-users', {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: user?.email,
          username: user?.name,
        }),
      });
    } catch (err) {
      console.log(err);
    }
  }, [user?.email, user?.name]);

  useEffect(() => {
    if (user?.email || user?.name) {
      fetchData();
    }
  }, [fetchData, user?.email, user?.name]);

  if (isLoading) {
    return <div>Loading ...</div>;
  }

  return (
    isAuthenticated && user ? (
      <div>
        Profile Picture: <img src={user.picture} alt={user.name} />
        <h2>User name: {user.name}</h2>
        <p>Email id: {user.email}</p>
      </div>
    ) : (
      <div>
        User not authenticated.
      </div>
    )
  );
};

export default Profile;
